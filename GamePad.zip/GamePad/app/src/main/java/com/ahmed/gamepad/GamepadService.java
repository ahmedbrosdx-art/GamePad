package com.ahmed.gamepad;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class GamepadService extends AccessibilityService {

    private static final long TICK = 80;
    private static final int MARKER_DP = 40;
    private static final Map<String, float[]> DEF = new HashMap<>();

    static {
        DEF.put("pad", new float[]{0.03f, 0.58f});
        DEF.put("btn1", new float[]{0.88f, 0.60f});
        DEF.put("btn2", new float[]{0.78f, 0.74f});
        DEF.put("btn3", new float[]{0.88f, 0.82f});
        DEF.put("btn4", new float[]{0.78f, 0.52f});
        DEF.put("m_pad", new float[]{0.10f, 0.30f});
        DEF.put("m_btn1", new float[]{0.80f, 0.30f});
        DEF.put("m_btn2", new float[]{0.86f, 0.38f});
        DEF.put("m_btn3", new float[]{0.92f, 0.30f});
        DEF.put("m_btn4", new float[]{0.86f, 0.22f});
        DEF.put("gear", new float[]{0.47f, 0.01f});
    }

    private static class Item {
        View v;
        WindowManager.LayoutParams lp;
        String key;
        int size;
        int sx, sy;
        float tx, ty;
    }

    private static class Ptr {
        float x, y, tx, ty;
        boolean ending;
        GestureDescription.StrokeDescription stroke;
    }

    private WindowManager wm;
    private SharedPreferences prefs;
    private int W, H;
    private boolean editMode = false;
    private final List<Item> controls = new ArrayList<>();
    private final List<Item> markers = new ArrayList<>();
    private Item gearItem, padItem;
    private TextView gearView;
    private Pad pad;
    private final Map<Integer, Ptr> ptrs = new LinkedHashMap<>();
    private boolean dispatching = false;

    private final GestureResultCallback cb = new GestureResultCallback() {
        @Override
        public void onCompleted(GestureDescription g) {
            dispatching = false;
            pump();
        }

        @Override
        public void onCancelled(GestureDescription g) {
            dispatching = false;
            for (Ptr p : ptrs.values()) p.stroke = null;
            pump();
        }
    };

    // ---------- lifecycle ----------

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        prefs = getSharedPreferences("gp", MODE_PRIVATE);
        build();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (wm != null) build();
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        teardown();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        teardown();
        super.onDestroy();
    }

    // ---------- helpers ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void updateMetrics() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        W = dm.widthPixels;
        H = dm.heightPixels;
    }

    private float[] frac(String key) {
        float[] d = DEF.get(key);
        return new float[]{
                prefs.getFloat(key + "_fx", d[0]),
                prefs.getFloat(key + "_fy", d[1])};
    }

    private float[] markerCenter(String key) {
        updateMetrics();
        float[] f = frac(key);
        int size = dp(MARKER_DP);
        int left = clamp((int) (f[0] * W), 0, W - size);
        int top = clamp((int) (f[1] * H), 0, H - size);
        return new float[]{left + size / 2f, top + size / 2f};
    }

    private WindowManager.LayoutParams newParams(int size, int x, int y) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = x;
        lp.y = y;
        return lp;
    }

    private Item addItem(View v, String key, int size, List<Item> list) {
        float[] f = frac(key);
        Item it = new Item();
        it.v = v;
        it.key = key;
        it.size = size;
        it.lp = newParams(size,
                clamp((int) (f[0] * W), 0, W - size),
                clamp((int) (f[1] * H), 0, H - size));
        try {
            wm.addView(v, it.lp);
        } catch (Exception ignored) { }
        if (list != null) list.add(it);
        return it;
    }

    private void removeAll(List<Item> list) {
        for (Item it : list) {
            try {
                wm.removeView(it.v);
            } catch (Exception ignored) { }
        }
        list.clear();
    }

    private void save(Item it) {
        prefs.edit()
                .putFloat(it.key + "_fx", it.lp.x / (float) W)
                .putFloat(it.key + "_fy", it.lp.y / (float) H)
                .apply();
    }

    private boolean drag(Item it, MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                it.sx = it.lp.x;
                it.sy = it.lp.y;
                it.tx = e.getRawX();
                it.ty = e.getRawY();
                return true;
            case MotionEvent.ACTION_MOVE:
                it.lp.x = clamp(it.sx + (int) (e.getRawX() - it.tx), 0, W - it.size);
                it.lp.y = clamp(it.sy + (int) (e.getRawY() - it.ty), 0, H - it.size);
                try {
                    wm.updateViewLayout(it.v, it.lp);
                } catch (Exception ignored) { }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                save(it);
                return true;
        }
        return true;
    }

    // ---------- build UI ----------

    private void teardown() {
        ptrs.clear();
        dispatching = false;
        if (wm == null) return;
        removeAll(controls);
        removeAll(markers);
        if (gearItem != null) {
            try {
                wm.removeView(gearItem.v);
            } catch (Exception ignored) { }
            gearItem = null;
        }
    }

    private void build() {
        teardown();
        updateMetrics();

        pad = new Pad(this);
        padItem = addItem(pad, "pad", dp(150), controls);

        String[] names = {"A", "B", "X", "Y"};
        for (int i = 0; i < 4; i++) {
            final int id = i + 1;
            final TextView b = makeCircle(names[i], Color.parseColor("#99455A64"), 22);
            final Item it = addItem(b, "btn" + id, dp(60), controls);
            b.setOnTouchListener((v, e) -> {
                if (editMode) return drag(it, e);
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        v.setAlpha(1f);
                        press(id);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.setAlpha(0.7f);
                        release(id);
                        return true;
                }
                return true;
            });
            b.setAlpha(0.7f);
        }

        gearView = makeCircle("⚙", Color.parseColor("#88000000"), 18);
        gearItem = addItem(gearView, "gear", dp(40), null);
        gearView.setOnClickListener(v -> setEdit(!editMode));

        editMode = false;
    }

    private TextView makeCircle(String text, int color, int sp) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(color);
        bg.setStroke(dp(2), Color.WHITE);
        t.setBackground(bg);
        return t;
    }

    private void setEdit(boolean on) {
        editMode = on;
        for (Ptr p : ptrs.values()) p.ending = true;
        pump();
        if (on) {
            addMarker("m_pad", "J");
            addMarker("m_btn1", "A");
            addMarker("m_btn2", "B");
            addMarker("m_btn3", "X");
            addMarker("m_btn4", "Y");
            gearView.setText("✔");
            Toast.makeText(this,
                    "اسحب النقاط الحمراء فوق أزرار اللعبة، واسحب يدي التحكم لأي مكان، ثم اضغط ✔",
                    Toast.LENGTH_LONG).show();
        } else {
            removeAll(markers);
            gearView.setText("⚙");
        }
        pad.invalidate();
    }

    private void addMarker(String key, String label) {
        TextView m = makeCircle(label, Color.parseColor("#BBE53935"), 16);
        final Item it = addItem(m, key, dp(MARKER_DP), markers);
        m.setOnTouchListener((v, e) -> drag(it, e));
    }

    // ---------- input -> gestures ----------

    private void press(int id) {
        float[] c = markerCenter("m_btn" + id);
        Ptr p = ptrs.get(id);
        if (p == null) {
            p = new Ptr();
            p.x = p.tx = c[0];
            p.y = p.ty = c[1];
            ptrs.put(id, p);
        }
        p.ending = false;
        pump();
    }

    private void release(int id) {
        Ptr p = ptrs.get(id);
        if (p != null) {
            p.ending = true;
            pump();
        }
    }

    private void joyUpdate(float nx, float ny) {
        float[] c = markerCenter("m_pad");
        float r = dp(70);
        float tx = Math.max(0, Math.min(W - 1, c[0] + nx * r));
        float ty = Math.max(0, Math.min(H - 1, c[1] + ny * r));
        Ptr p = ptrs.get(0);
        if (p == null) {
            p = new Ptr();
            p.x = c[0];
            p.y = c[1];
            ptrs.put(0, p);
        }
        p.ending = false;
        p.tx = tx;
        p.ty = ty;
        pump();
    }

    private void joyRelease() {
        Ptr p = ptrs.get(0);
        if (p != null) {
            p.ending = true;
            pump();
        }
    }

    private void pump() {
        if (dispatching || ptrs.isEmpty()) return;
        GestureDescription.Builder gb = new GestureDescription.Builder();
        Iterator<Map.Entry<Integer, Ptr>> it = ptrs.entrySet().iterator();
        while (it.hasNext()) {
            Ptr p = it.next().getValue();
            Path path = new Path();
            path.moveTo(p.x, p.y);
            path.lineTo(p.tx, p.ty);
            boolean cont = !p.ending;
            GestureDescription.StrokeDescription s = (p.stroke == null)
                    ? new GestureDescription.StrokeDescription(path, 0, TICK, cont)
                    : p.stroke.continueStroke(path, 0, TICK, cont);
            gb.addStroke(s);
            p.stroke = s;
            p.x = p.tx;
            p.y = p.ty;
            if (p.ending) it.remove();
        }
        boolean ok;
        try {
            ok = dispatchGesture(gb.build(), cb, null);
        } catch (Exception e) {
            ok = false;
        }
        dispatching = ok;
        if (!ok) ptrs.clear();
    }

    // ---------- joystick view ----------

    private class Pad extends View {
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float kx, ky;

        Pad(Context c) {
            super(c);
            fill.setColor(Color.parseColor("#44FFFFFF"));
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(2));
            ring.setColor(Color.WHITE);
            knob.setColor(Color.parseColor("#CC1E88E5"));
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float r = Math.min(cx, cy) - dp(2);
            c.drawCircle(cx, cy, r, fill);
            c.drawCircle(cx, cy, r, ring);
            c.drawCircle(cx + kx, cy + ky, r * 0.35f, knob);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (editMode) return drag(padItem, e);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float R = Math.min(cx, cy) * 0.65f;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getX() - cx, dy = e.getY() - cy;
                    float len = (float) Math.sqrt(dx * dx + dy * dy);
                    if (len > R) {
                        dx *= R / len;
                        dy *= R / len;
                        len = R;
                    }
                    kx = dx;
                    ky = dy;
                    invalidate();
                    float nx = dx / R, ny = dy / R;
                    if (len < R * 0.2f) {
                        nx = 0;
                        ny = 0;
                    }
                    joyUpdate(nx, ny);
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    kx = 0;
                    ky = 0;
                    invalidate();
                    joyRelease();
                    return true;
            }
            return true;
        }
    }
}
