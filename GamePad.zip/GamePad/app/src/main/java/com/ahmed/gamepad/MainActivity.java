package com.ahmed.gamepad;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);

        TextView info = new TextView(this);
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        info.setText("1) اضغط \"فتح إعدادات إمكانية الوصول\" وفعّل \"يد التحكم\"\n"
                + "2) لو الخيار رمادي: اضغط \"معلومات التطبيق\" ثم ⋮ ثم \"السماح بالإعدادات المقيّدة\"\n"
                + "3) افتح اللعبة، واضغط ⚙ فوق لتعديل أماكن الأزرار\n"
                + "4) ضع النقاط الحمراء فوق أزرار اللعبة، ثم اضغط ✔");
        root.addView(info);

        Button acc = new Button(this);
        acc.setText("فتح إعدادات إمكانية الوصول");
        acc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(acc);

        Button det = new Button(this);
        det.setText("معلومات التطبيق");
        det.setOnClickListener(v -> startActivity(new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        root.addView(det);

        setContentView(root);
    }
}
